EDITH SMP - ROYAL AMETHYST RESOURCE PACK
========================================

Target: Minecraft Java Edition 1.21.11 and newer (26.x)
Pack format: min_format 75, max_format 999 (works on 1.21.11 and every later version)

WHAT'S INCLUDED
- Custom Edith SMP pack icon
- Purple royal-themed title-screen panorama
- Purple/gold custom GUI button textures
- Purple/gold player inventory and chest screens (also used by double chests, ender chests and barrels)
- Edith SMP logo asset
- Selected English menu-label overrides

IMPORTANT LIMITATION
A normal Minecraft Java resource pack cannot replace the entire in-game pause menu with a fully custom layout or insert a custom logo/message into the pause screen. It can replace supported textures and language strings. The included panorama changes the title-screen background; the in-world pause screen continues to show the paused world behind the menu.

SERVER REQUIRED DOWNLOAD
1. Upload Edith_SMP_Resource_Pack.zip to a direct HTTPS file host.
2. Copy the direct download URL.
3. In server.properties, set:
   require-resource-pack=true
   resource-pack=<DIRECT_HTTPS_ZIP_URL>
   resource-pack-sha1=<SHA1_OF_ZIP>
4. Restart the server.

To calculate SHA1 on Windows PowerShell:
  (Get-FileHash .\Edith_SMP_Resource_Pack.zip -Algorithm SHA1).Hash.ToLower()

For Paper, server.properties is in the server root. Make sure the URL downloads the ZIP directly and is publicly reachable.

INSTALL LOCALLY
- Put the ZIP in .minecraft/resourcepacks
- Enable it in Options > Resource Packs

NOTE
Button sprites include nine-slice .mcmeta files (required since 1.20.2) and the panorama faces are square 1024x1024 cubemap faces, as the game expects.
